<?php 
    require 'includes/app.php';
    incluirTemplate('header');
?>

    <?php 
    incluirTemplate('footer'); 
    ?>


 