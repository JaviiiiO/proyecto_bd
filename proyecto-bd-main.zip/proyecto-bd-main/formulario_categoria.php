<fieldset>
    <legend>Información General</legend>

    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="categoria[nombre]" placeholder="Nombre categoria" value="<?php echo s( $categoria->nombre ); ?>">

</fieldset>