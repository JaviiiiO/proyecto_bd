<footer class="footer seccion">
        <div class="contendor contenedor-footer">
            <nav class="navegacion">
            <a href="nosotros.php">Nosotros</a>
            <a href="Productos.php">Productos</a>
            <a href="essential.php">Essential Everyday</a>
            </nav>
        </div>
        <p class="copyright">Todos los derechos reservados <?php echo date('Y'); ?> &copy;</p>
    </footer>
    <script src="src/js/app.js"></script>

</body>
</html>