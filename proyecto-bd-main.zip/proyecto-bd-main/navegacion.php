<nav>
    <ul>
    <a  href="index.php">
                    <img src="build/img/logoclaro.svg" alt="">
                
                </a>
        <li><a href="Productos.php">Productos</a></li>
        <li><a href="essential.php">Essential Everyday</a></li>
        <li class="carrito">
            <a href="#" class='btn-carrito'>Carrito</a>
                <div id="carrito-container">
                    <div id="tabla">

                    </div>
                </div>
        </li>
    </ul>
</nav>